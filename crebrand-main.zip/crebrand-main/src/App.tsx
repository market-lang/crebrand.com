/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import Header from './components/Header';
import HomeView from './components/HomeView';
import CaseStudyView from './components/CaseStudyView';
import EnquiryModal from './components/EnquiryModal';
import { PageId } from './types';

export default function App() {
  const [currentPage, setCurrentPage] = useState<PageId>('home');
  const [isEnquiryModalOpen, setIsEnquiryModalOpen] = useState(false);
  const [enquiryBrandType, setEnquiryBrandType] = useState('Home');

  // Multi-page hash routing synchronization
  useEffect(() => {
    const parseHashRoute = () => {
      const hash = window.location.hash;
      if (hash.startsWith('#/case-study/')) {
        const routeId = hash.replace('#/case-study/', '');
        const validRoutes: PageId[] = ['beauty', 'fitness', 'home-collection', 'apparel', 'tech', 'wellness'];
        if (validRoutes.includes(routeId as PageId)) {
          setCurrentPage(routeId as PageId);
          window.scrollTo({ top: 0, behavior: 'instant' });
        } else {
          setCurrentPage('home');
        }
      } else {
        setCurrentPage('home');
      }
    };

    window.addEventListener('hashchange', parseHashRoute);
    parseHashRoute(); // Initialize on initial render

    return () => {
      window.removeEventListener('hashchange', parseHashRoute);
    };
  }, []);

  // Secure navigation function
  const handlePageChange = (page: PageId) => {
    setCurrentPage(page);
    if (page === 'home') {
      window.location.hash = '';
    } else {
      window.location.hash = `#/case-study/${page}`;
    }
  };

  // Open Enquiry with dynamic content highlighted
  const handleEnquireClick = (brandType?: string) => {
    if (brandType) {
      setEnquiryBrandType(brandType);
    } else {
      // Default fallback based on currently visited page
      if (currentPage === 'beauty') setEnquiryBrandType('Skincare');
      else if (currentPage === 'fitness') setEnquiryBrandType('Fitness');
      else if (currentPage === 'home-collection') setEnquiryBrandType('Home');
      else if (currentPage === 'apparel') setEnquiryBrandType('Apparel');
      else if (currentPage === 'tech') setEnquiryBrandType('Tech');
      else if (currentPage === 'wellness') setEnquiryBrandType('Wellness');
      else setEnquiryBrandType('Home');
    }
    setIsEnquiryModalOpen(true);
  };

  return (
    <div className="bg-luxury-linen text-luxury-dark min-h-screen selection:bg-luxury-gold selection:text-luxury-dark antialiased">
      {/* Dynamic Header with state syncing */}
      <Header 
        currentPage={currentPage} 
        setCurrentPage={handlePageChange} 
        onEnquireClick={() => handleEnquireClick()} 
      />

      <main className="min-h-[80vh]">
        {currentPage === 'home' ? (
          <HomeView 
            setCurrentPage={handlePageChange} 
            onEnquireClick={handleEnquireClick} 
          />
        ) : (
          <CaseStudyView 
            pageId={currentPage} 
            setCurrentPage={handlePageChange} 
            onEnquireClick={handleEnquireClick} 
          />
        )}
      </main>

      {/* Global Interactive Booking Modal */}
      <EnquiryModal 
        isOpen={isEnquiryModalOpen} 
        onClose={() => setIsEnquiryModalOpen(false)} 
        defaultBrandType={enquiryBrandType} 
      />
    </div>
  );
}
