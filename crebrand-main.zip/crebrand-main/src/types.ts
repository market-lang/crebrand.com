export type PageId = 'home' | 'beauty' | 'fitness' | 'home-collection' | 'apparel' | 'tech' | 'wellness';

export interface FAQItem {
  id: string;
  question: string;
  answer: string;
}

export interface ServiceItem {
  id: string;
  title: string;
  subtitle: string;
  description: string;
  image: string;
}

export interface CategoryCard {
  id: PageId;
  name: string;
  subtitle: string;
  image: string;
  accentTitle: string;
}

export interface CaseStudy {
  id: PageId;
  title: string;
  subtitle: string;
  heroImage: string;
  visionText: string;
  visionImage: string;
  collectionText: string;
  collectionImage: string;
  products: {
    name: string;
    image: string;
    description?: string;
  }[];
  processSteps: {
    name: string;
    image: string;
    caption?: string;
  }[];
}
