import React, { useState } from 'react';
import { X, Check } from 'lucide-react';
import Logo from './Logo';

interface EnquiryModalProps {
  isOpen: boolean;
  onClose: () => void;
  defaultBrandType?: string;
}

export default function EnquiryModal({ isOpen, onClose, defaultBrandType = 'Home' }: EnquiryModalProps) {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [brandType, setBrandType] = useState(defaultBrandType);
  const [message, setMessage] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    // Simulate luxury API response perfectly
    setTimeout(() => {
      setIsLoading(false);
      setIsSubmitted(true);
    }, 1200);
  };

  const handleReset = () => {
    setName('');
    setEmail('');
    setPhone('');
    setBrandType('Home');
    setMessage('');
    setIsSubmitted(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
      <div 
        className="relative w-full max-w-xl overflow-hidden bg-white border border-gray-200 rounded-none shadow-2xl transition-all"
        id="enquiry-modal-container"
      >
        {/* Luxury top borders */}
        <div className="h-1 bg-gradient-to-r from-luxury-gold-dark via-luxury-gold to-luxury-gold-light" />
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-gray-400 hover:text-luxury-dark transition-colors duration-200 cursor-pointer"
          aria-label="Close modal"
          id="close-enquiry-modal"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="p-8 md:p-10">
          {!isSubmitted ? (
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="text-center space-y-2">
                <div className="flex justify-center mb-2">
                  <Logo className="h-8 text-luxury-dark" />
                </div>
                <h3 className="font-display text-2.5xl tracking-widest text-luxury-dark font-bold uppercase">
                  PARTNER WITH CREATORBRAND
                </h3>
                <p className="text-xs tracking-wider text-gray-500 uppercase">
                  Let's bring your creator brand to life
                </p>
              </div>

              <div className="space-y-4">
                {/* Full name input */}
                <div>
                  <label className="block text-[10px] tracking-wider text-luxury-gold-dark font-bold uppercase mb-1">
                    Your Name / Creator Identity *
                  </label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full px-4 py-3 bg-luxury-linen border border-gray-200 text-luxury-dark text-sm focus:outline-none focus:border-luxury-gold-dark tracking-wide rounded-none transition-all duration-200"
                    placeholder="e.g. Alexis Wright"
                  />
                </div>

                {/* Email address */}
                <div>
                  <label className="block text-[10px] tracking-wider text-luxury-gold-dark font-bold uppercase mb-1">
                    Email Address *
                  </label>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full px-4 py-3 bg-luxury-linen border border-gray-200 text-luxury-dark text-sm focus:outline-none focus:border-luxury-gold-dark tracking-wide rounded-none transition-all duration-200"
                    placeholder="creator@example.com"
                  />
                  <p className="mt-1 text-[9px] text-gray-500">
                    Pre-configured response will route details to market@creatorbrand.com
                  </p>
                </div>

                {/* Brand Type Select */}
                <div>
                  <label className="block text-[10px] tracking-wider text-luxury-gold-dark font-bold uppercase mb-1">
                    Brand Category of Interest
                  </label>
                  <select
                    value={brandType}
                    onChange={(e) => setBrandType(e.target.value)}
                    className="w-full px-4 py-3 bg-luxury-linen border border-gray-200 text-luxury-dark text-sm focus:outline-none focus:border-luxury-gold-dark tracking-wide rounded-none transition-all duration-200 cursor-pointer"
                  >
                    <option value="Skincare">Beauty / Skincare</option>
                    <option value="Fitness">Fitness / Performance Line</option>
                    <option value="Home">Home Collection</option>
                    <option value="Apparel">Apparel Capsule</option>
                    <option value="Tech">Tech Essentials</option>
                    <option value="Wellness">Wellness Rituals</option>
                  </select>
                </div>

                {/* Project Vision message */}
                <div>
                  <label className="block text-[10px] tracking-wider text-luxury-gold-dark font-bold uppercase mb-1">
                    Brief Vision for your Collection (Optional)
                  </label>
                  <textarea
                    rows={3}
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    className="w-full px-4 py-3 bg-luxury-linen border border-gray-200 text-luxury-dark text-sm focus:outline-none focus:border-luxury-gold-dark tracking-wide rounded-none transition-all duration-200 resize-none"
                    placeholder="Tell us about your audience size, product aesthetic and dream timeline..."
                  />
                </div>
              </div>

              {/* Submit button */}
              <button
                type="submit"
                disabled={isLoading}
                className="relative w-full py-4 overflow-hidden bg-luxury-dark hover:bg-luxury-gold-dark text-white font-sans text-xs font-semibold tracking-widest uppercase transition-all duration-300 rounded-none cursor-pointer hover:shadow-md"
                id="submit-enquiry"
              >
                {isLoading ? (
                  <span className="inline-flex items-center space-x-2 animate-pulse">
                    <span className="w-2 h-2 bg-white rounded-full" />
                    <span>TRANSMITTING INITIATIVE...</span>
                  </span>
                ) : (
                  <span>SEND SECURE ENQUIRY</span>
                )}
              </button>
            </form>
          ) : (
            <div className="py-8 text-center space-y-6">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-luxury-linen border border-luxury-gold-dark text-luxury-gold-dark mb-2">
                <Check className="w-8 h-8" />
              </div>
              <div className="space-y-2">
                <h3 className="font-display text-2.5xl tracking-widest text-luxury-dark uppercase font-bold">
                  COMMUNICATION INITIATED
                </h3>
                <p className="text-xs text-gray-600 max-w-sm mx-auto leading-relaxed">
                  Thank you, <span className="text-luxury-gold-dark font-bold">{name}</span>. A luxury brand strategist has been notified and will prepare custom mockups for your <span className="text-luxury-gold-dark font-bold">{brandType}</span> brand.
                </p>
                <p className="text-[11px] text-gray-500">
                  Confirmation credentials have been routed to market@creatorbrand.com.
                </p>
              </div>
              
              <button
                onClick={handleReset}
                className="px-8 py-3 bg-transparent border border-luxury-dark hover:bg-luxury-dark hover:text-white text-luxury-dark text-xs tracking-widest uppercase transition-all duration-300 rounded-none cursor-pointer font-bold"
                id="close-success-enquiry"
              >
                RETURN TO GALLERY
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
