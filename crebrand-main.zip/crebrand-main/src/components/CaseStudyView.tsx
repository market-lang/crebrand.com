import React from 'react';
import { motion } from 'motion/react';
import { ArrowLeft, Sparkles, Shield, Compass, Calendar, ArrowRight } from 'lucide-react';
import { PageId, CaseStudy } from '../types';
import { caseStudiesData } from '../data/caseStudiesData';
import Footer from './Footer';

interface CaseStudyViewProps {
  pageId: PageId;
  setCurrentPage: (page: PageId) => void;
  onEnquireClick: (brandType?: string) => void;
}

export default function CaseStudyView({ pageId, setCurrentPage, onEnquireClick }: CaseStudyViewProps) {
  const data: CaseStudy | undefined = caseStudiesData[pageId];

  // Fallback if pageId is not found
  if (!data) {
    return (
      <div className="py-32 text-center space-y-6">
        <p className="text-luxury-gold tracking-widest text-sm uppercase">CASE RECORD NOT FOUND</p>
        <button 
          onClick={() => setCurrentPage('home')}
          className="px-6 py-2 border border-luxury-gold text-luxury-gold text-xs tracking-widest uppercase"
        >
          Return Home
        </button>
      </div>
    );
  }

  return (
    <motion.div 
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.8, ease: 'easeOut' }}
      className="bg-luxury-linen text-luxury-dark min-h-screen text-left"
      id={`case-study-view-${pageId}`}
    >
      {/* -------------------- BRAND HEADER BAR -------------------- */}
      <div className="bg-white border-b border-gray-200/80 sticky top-20 z-30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-14 flex items-center justify-between text-xs tracking-widest uppercase font-semibold">
          <button 
            onClick={() => {
              setCurrentPage('home');
              const target = document.getElementById('categories');
              if (target) {
                setTimeout(() => target.scrollIntoView({ behavior: 'smooth' }), 50);
              } else {
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }
            }}
            className="inline-flex items-center space-x-2 text-gray-500 hover:text-luxury-dark transition-colors duration-200 cursor-pointer"
            id="case-study-back-btn" 
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>BACK TO GALLERY</span>
          </button>
          <div className="flex items-center space-x-2 text-[11px] text-luxury-gold font-bold">
            <span className="hidden sm:inline text-gray-400 font-medium">CATEGORY:</span>
            <span>{data.title.toUpperCase()}</span>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-24 space-y-24">
        
        {/* -------------------- TITLE & SUBTITLE -------------------- */}
        <div className="text-center space-y-4 max-w-4xl mx-auto">
          <h1 className="font-display text-3xl sm:text-5xl md:text-6xl font-bold tracking-[0.05em] uppercase leading-tight text-luxury-dark select-none">
            {data.subtitle}
          </h1>
          <div className="w-16 h-[2px] bg-luxury-gold mx-auto" />
          <p className="font-serif text-base sm:text-xl text-gray-600 tracking-wide max-w-2xl mx-auto italic">
            {data.subtitle === 'EDITORIAL CASE STUDY: SKINCARE' ? (
              <span>The journey of a creator's premium skincare line.</span>
            ) : data.subtitle === 'CASE STUDY: FITNESS PERFORMANCE LINE' ? (
              <span>A luxury creator brand studio case study.</span>
            ) : data.subtitle === 'CASE STUDY: HOME COLLECTION' ? (
              <span>The journey of a creator's minimalist home decor line.</span>
            ) : data.subtitle === 'CASE STUDY: APPAREL CAPSULE' ? (
              <span>The journey of a creator's premium designer clothing line.</span>
            ) : data.subtitle === 'CASE STUDY: TECH ESSENTIALS' ? (
              <span>The journey of a creator's premium tech accessory line.</span>
            ) : (
              <span>A holistic wellness line case study for a creator brand.</span>
            )}
          </p>
        </div>

        {/* -------------------- 1. THE VISION SECTION -------------------- */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-10 md:gap-16 items-center">
          {/* Vision image left side (occupies 5 columns) */}
          <div className="md:col-span-5 h-[400px] sm:h-[500px] overflow-hidden bg-gray-200 shadow-xl border border-gray-100">
            <img 
              src={data.visionImage} 
              alt={`${data.title} Vision aspect`} 
              className="w-full h-full object-cover grayscale contrast-115 transform hover:scale-[1.02] hover:grayscale-0 transition-all duration-700"
              referrerPolicy="no-referrer"
            />
          </div>

          {/* Vision copy right side (occupies 7 columns) */}
          <div className="md:col-span-7 space-y-6 text-left">
            <h2 className="font-display text-4xl sm:text-5xl font-semibold tracking-widest text-luxury-dark uppercase">
              THE VISION
            </h2>
            <div className="h-[1px] w-12 bg-luxury-gold" />
            <p className="font-serif text-sm sm:text-base leading-relaxed text-gray-700 font-normal">
              {data.visionText}
            </p>
            <div className="pt-4 grid grid-cols-2 gap-6 text-[11px] tracking-widest text-gray-500 uppercase font-semibold">
              <div className="space-y-1 bg-white/70 p-4 border border-gray-200/50">
                <div className="text-luxury-gold font-bold text-xs uppercase">MATERIAL TRUTH</div>
                <div>Single-Source, Raw Crafts</div>
              </div>
              <div className="space-y-1 bg-white/70 p-4 border border-gray-200/50">
                <div className="text-luxury-gold font-bold text-xs uppercase">GEOGRAPHIC ORIGIN</div>
                <div>Custom Local Kilns / Labs</div>
              </div>
            </div>
          </div>
        </div>

        {/* -------------------- 2. THE COLLECTION SECTION -------------------- */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-10 md:gap-16 items-center">
          {/* Collection copy left side (occupies 7 columns on md/lg, ordered first on mobile) */}
          <div className="md:col-span-7 space-y-6 text-left md:order-1">
            <h2 className="font-display text-4xl sm:text-5xl font-semibold tracking-widest text-luxury-dark uppercase">
              THE COLLECTION
            </h2>
            <div className="h-[1px] w-12 bg-luxury-gold" />
            <p className="font-serif text-sm sm:text-base leading-relaxed text-gray-700 font-normal">
              {data.collectionText}
            </p>
            
            {/* Horizontal or compact lists of features */}
            <div className="space-y-3 pt-2 text-xs text-gray-600 sm:font-medium tracking-wide">
              {data.id === 'beauty' && (
                <>
                  <div className="flex items-center space-x-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-luxury-gold" />
                    <span>Radiant Hydrolat face oil base</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-luxury-gold" />
                    <span>Lead-free recycled pharmaceutical boroscilate glass</span>
                  </div>
                </>
              )}
              {data.id === 'home-collection' && (
                <>
                  <div className="flex items-center space-x-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-luxury-gold" />
                    <span>Fired under 1250°C in traditional Ishikawa clay rings</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-luxury-gold" />
                    <span>Pure cold-extracted botanical aromatherapy blends</span>
                  </div>
                </>
              )}
              {data.id === 'apparel' && (
                <>
                  <div className="flex items-center space-x-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-luxury-gold" />
                    <span>32-momme organic mulberry fiber</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-luxury-gold" />
                    <span>Neutral-earth pigment dying method safe for water cycles</span>
                  </div>
                </>
              )}
              {data.id === 'tech' && (
                <>
                  <div className="flex items-center space-x-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-luxury-gold" />
                    <span>Top-tier heavy Tuscan vegetable tanned grain hide</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-luxury-gold" />
                    <span>Modular gold-clad magnetic connector components</span>
                  </div>
                </>
              )}
              {data.id === 'fitness' && (
                <>
                  <div className="flex items-center space-x-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-luxury-gold" />
                    <span>Tear-resistant double knit composite webbing</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-luxury-gold" />
                    <span>Insulated physical double walled shaker layout</span>
                  </div>
                </>
              )}
              {data.id === 'wellness' && (
                <>
                  <div className="flex items-center space-x-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-luxury-gold" />
                    <span>Wild mountain sage and raw white quartz specimens</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-luxury-gold" />
                    <span>Kyoto traditional hand-beaten temple brass</span>
                  </div>
                </>
              )}
            </div>
          </div>

          {/* Collection image right side (occupies 5 columns) */}
          <div className="md:col-span-5 h-[400px] sm:h-[500px] overflow-hidden bg-gray-200 shadow-xl border border-gray-100 md:order-2">
            <img 
              src={data.collectionImage} 
              alt={`${data.title} Collection aspect`} 
              className="w-full h-full object-cover grayscale contrast-115 transform hover:scale-[1.02] hover:grayscale-0 transition-all duration-700"
              referrerPolicy="no-referrer"
            />
          </div>
        </div>

        {/* -------------------- 3. GRID OF PRODUCTS -------------------- */}
        <div className="space-y-12">
          <div className="text-center space-y-2">
            <span className="text-[10px] tracking-[0.3em] text-luxury-gold uppercase font-bold">PORTFOLIO INDEX</span>
            <h3 className="font-display text-2xl tracking-widest text-luxury-dark uppercase font-bold">CORE CAPABILITIES DETAIL</h3>
            <div className="w-12 h-[1px] bg-luxury-gold mx-auto" />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {data.products.map((prod, pIdx) => (
              <div 
                key={prod.name} 
                className="bg-white p-6 border border-gray-200/60 shadow-lg hover:shadow-2xl transition-all duration-300 flex flex-col justify-between group h-full"
                id={`product-card-${pIdx}`}
              >
                <div className="space-y-4">
                  {/* Aspect Product view */}
                  <div className="h-56 w-full overflow-hidden relative">
                    <img 
                      src={prod.image} 
                      alt={prod.name} 
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/20 to-transparent h-12" />
                    <div className="absolute top-2 left-2 bg-luxury-linen px-2 py-0.5 border border-luxury-gold/20 text-[9px] text-luxury-gold font-bold tracking-widest">
                      ITEM 0{pIdx + 1}
                    </div>
                  </div>
                  
                  <h4 className="font-display text-sm tracking-wider font-bold text-luxury-dark uppercase group-hover:text-luxury-gold transition-colors pt-2">
                    {prod.name}
                  </h4>
                  <p className="text-[11px] sm:text-xs text-gray-500 tracking-wide leading-relaxed font-serif">
                    {prod.description || 'Premium physical item designed exclusively for your community.'}
                  </p>
                </div>

                <div className="pt-4 border-t border-gray-100 mt-4 flex items-center justify-between text-[10px] tracking-widest font-semibold text-luxury-gold uppercase">
                  <span>SPEC SHEET AVAILABLE</span>
                  <ArrowRight className="w-3 h-3 group-hover:translate-x-1 transform transition-transform" />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* -------------------- 4. THE PROCESS PROTOCOL HORIZONTAL ROWS -------------------- */}
        <div className="space-y-12">
          <div className="text-center space-y-2">
            <span className="text-[10px] tracking-[0.3em] text-luxury-gold uppercase font-bold">SOVEREIGN WORKFLOW</span>
            <h3 className="font-display text-2xl tracking-widest text-luxury-dark uppercase font-bold">THE PROCESS</h3>
            <div className="w-12 h-[1px] bg-luxury-gold mx-auto" />
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {data.processSteps.map((step, sIdx) => (
              <div 
                key={sIdx} 
                className="bg-white/80 p-4 border border-gray-200/50 shadow-md text-center space-y-4 hover:bg-white transition-all"
                id={`process-col-${sIdx}`}
              >
                <div className="h-44 overflow-hidden shadow-inner bg-gray-100">
                  <img 
                    src={step.image} 
                    alt={step.name} 
                    className="w-full h-full object-cover grayscale brightness-95"
                    referrerPolicy="no-referrer"
                  />
                </div>
                <div className="space-y-1">
                  <div className="text-[9px] uppercase tracking-widest text-luxury-gold font-bold">PHASE 0{sIdx + 1}</div>
                  <h5 className="font-display text-[10px] sm:text-xs font-bold uppercase tracking-wider text-luxury-dark truncate px-1">
                    {step.name}
                  </h5>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* -------------------- Centered Outlined CTA: ENQUIRE NOW -------------------- */}
        <div className="text-center space-y-6 pt-12 border-t border-gray-200 max-w-2xl mx-auto">
          <p className="text-xs uppercase tracking-[0.3em] text-gray-500 font-semibold">
            DEVELOP YOUR SPHERES
          </p>
          <h3 className="font-display text-2xl sm:text-3xl text-luxury-dark tracking-widest font-bold uppercase">
            Inception Consultation
          </h3>
          <p className="text-xs tracking-wide text-gray-600 max-w-md mx-auto leading-relaxed font-serif italic">
            Schedule a confidential call with a project architect to explore design templates and supply capacities for your elite digital brand.
          </p>
          <div className="pt-4 flex justify-center">
            <button
              onClick={() => onEnquireClick(data.title)}
              className="px-14 py-5 bg-transparent border-2 border-luxury-dark text-luxury-dark hover:bg-luxury-dark hover:text-white text-xs font-bold tracking-widest uppercase rounded-none cursor-pointer transition-all duration-300"
              id="middle-enquire-now-btn"
            >
              ENQUIRE NOW
            </button>
          </div>
        </div>

      </div>

      {/* Internal beautiful footer inside each case study view */}
      <div className="bg-white pt-8">
        <Footer setCurrentPage={setCurrentPage} onEnquireClick={() => onEnquireClick()} />
      </div>

    </motion.div>
  );
}
