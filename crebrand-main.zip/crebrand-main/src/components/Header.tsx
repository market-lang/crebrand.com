import React from 'react';
import { ArrowLeft, Send } from 'lucide-react';
import Logo from './Logo';
import { PageId } from '../types';

interface HeaderProps {
  currentPage: PageId;
  setCurrentPage: (page: PageId) => void;
  onEnquireClick: () => void;
}

export default function Header({ currentPage, setCurrentPage, onEnquireClick }: HeaderProps) {
  const isHome = currentPage === 'home';

  const formatPageName = (page: PageId) => {
    switch (page) {
      case 'beauty': return 'SKINCARE';
      case 'fitness': return 'FITNESS & PERFORMANCE';
      case 'home-collection': return 'HOME DECOR';
      case 'apparel': return 'APPAREL';
      case 'tech': return 'TECH ESSENTIALS';
      case 'wellness': return 'WELLNESS RITUALS';
      default: return '';
    }
  };

  return (
    <header className="sticky top-0 z-40 w-full bg-white/80 backdrop-blur-md border-b border-gray-200/40 transition-all duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between gap-4 md:gap-8">
        {/* Left Side: Brand Logo */}
        <div 
          onClick={() => {
            setCurrentPage('home');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          className="cursor-pointer group flex items-center space-x-2 flex-shrink-0"
          id="header-logo-link"
        >
          <Logo className="h-7 text-luxury-dark group-hover:text-luxury-gold-dark transition-colors duration-300" />
        </div>

        {/* Middle Navigation / Breadcrumb */}
        <div className="hidden md:flex items-center text-[10px] lg:text-[11px] tracking-[0.2em] lg:tracking-[0.25em] uppercase text-gray-500 flex-grow justify-center">
          {isHome ? (
            <div className="flex items-center space-x-3 lg:space-x-6 font-medium text-gray-600">
              <a href="#hero" className="hover:text-luxury-gold-dark transition-colors py-2 px-1">Hero</a>
              <span className="text-gray-300/60 font-serif select-none text-[8px]">•</span>
              <a href="#services" className="hover:text-luxury-gold-dark transition-colors py-2 px-1">Services</a>
              <span className="text-gray-300/60 font-serif select-none text-[8px]">•</span>
              <a href="#categories" className="hover:text-luxury-gold-dark transition-colors py-2 px-1">Collection</a>
              <span className="text-gray-300/60 font-serif select-none text-[8px]">•</span>
              <a href="#process" className="hover:text-luxury-gold-dark transition-colors py-2 px-1">Process</a>
              <span className="text-gray-300/60 font-serif select-none text-[8px]">•</span>
              <a href="#faq" className="hover:text-luxury-gold-dark transition-colors py-2 px-1">FAQ</a>
            </div>
          ) : (
            <button
              onClick={() => {
                setCurrentPage('home');
                const target = document.getElementById('categories');
                if (target) {
                  setTimeout(() => target.scrollIntoView({ behavior: 'smooth' }), 50);
                } else {
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }
              }}
              className="inline-flex items-center space-x-2 text-luxury-dark hover:text-luxury-gold-dark transition-colors duration-200 cursor-pointer font-medium whitespace-nowrap"
              id="back-to-home-link"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>BACK TO GALLERY</span>
              <span className="text-gray-300">/</span>
              <span className="text-luxury-gold-dark font-semibold">{formatPageName(currentPage)}</span>
            </button>
          )}
        </div>

        {/* Right Side: CTA Button */}
        <div className="flex items-center space-x-4 flex-shrink-0">
          {!isHome && (
            <button
              onClick={() => {
                setCurrentPage('home');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="md:hidden text-xs text-luxury-gold-dark uppercase hover:underline"
            >
              Back
            </button>
          )}
          <button
            onClick={onEnquireClick}
            className="px-6 py-3 whitespace-nowrap bg-luxury-dark hover:bg-luxury-gold-dark text-white text-[10px] sm:text-xs font-semibold tracking-widest uppercase transition-all duration-300 rounded-none cursor-pointer shadow-md flex-shrink-0"
            id="header-enquire-now"
          >
            Enquire Now
          </button>
        </div>
      </div>
    </header>
  );
}
