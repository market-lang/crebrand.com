import React from 'react';
import Logo from './Logo';
import { PageId } from '../types';
import { Facebook, Instagram, Youtube, ArrowUp } from 'lucide-react';

interface FooterProps {
  setCurrentPage: (page: PageId) => void;
  onEnquireClick: () => void;
}

export default function Footer({ setCurrentPage, onEnquireClick }: FooterProps) {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-white text-luxury-dark border-t border-gray-200/60 py-16 md:py-20 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Top footer row */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-16">
          {/* Col 1: Brand details */}
          <div className="md:col-span-2 space-y-6">
            <Logo className="h-9 text-luxury-dark" />
            <p className="text-gray-500 text-xs sm:text-sm tracking-wide leading-relaxed max-w-sm">
              We translate digital influence into enduring luxury physical portfolios. Seamlessly integrating strategic design, sovereign manufacturing, and universal logistics.
            </p>
            <div className="flex items-center space-x-4 pt-2">
              <a href="#" className="w-9 h-9 flex items-center justify-center rounded-full bg-luxury-linen border border-gray-200/50 text-gray-500 hover:text-luxury-dark hover:border-luxury-dark hover:bg-white transition-all duration-300">
                <Facebook className="w-4 h-4" />
              </a>
              <a href="#" className="w-9 h-9 flex items-center justify-center rounded-full bg-luxury-linen border border-gray-200/50 text-gray-500 hover:text-luxury-dark hover:border-luxury-dark hover:bg-white transition-all duration-300">
                <Instagram className="w-4 h-4" />
              </a>
              <a href="#" className="w-9 h-9 flex items-center justify-center rounded-full bg-luxury-linen border border-gray-200/50 text-gray-500 hover:text-luxury-dark hover:border-luxury-dark hover:bg-white transition-all duration-300">
                <Youtube className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Col 2: Brand Verticals */}
          <div className="space-y-4">
            <h4 className="font-display text-xs tracking-widest text-luxury-gold-dark font-bold uppercase">
              Brand Verticals
            </h4>
            <div className="flex flex-col space-y-2 text-xs tracking-wider text-gray-500">
              <button onClick={() => { setCurrentPage('beauty'); scrollToTop(); }} className="text-left hover:text-luxury-dark transition-colors duration-200 cursor-pointer">Skincare & Beauty</button>
              <button onClick={() => { setCurrentPage('fitness'); scrollToTop(); }} className="text-left hover:text-luxury-dark transition-colors duration-200 cursor-pointer">Fitness Performance</button>
              <button onClick={() => { setCurrentPage('home-collection'); scrollToTop(); }} className="text-left hover:text-luxury-dark transition-colors duration-200 cursor-pointer">Home Collection</button>
              <button onClick={() => { setCurrentPage('apparel'); scrollToTop(); }} className="text-left hover:text-luxury-dark transition-colors duration-200 cursor-pointer">Apparel Capsule</button>
              <button onClick={() => { setCurrentPage('tech'); scrollToTop(); }} className="text-left hover:text-luxury-dark transition-colors duration-200 cursor-pointer">Tech Essentials</button>
              <button onClick={() => { setCurrentPage('wellness'); scrollToTop(); }} className="text-left hover:text-luxury-dark transition-colors duration-200 cursor-pointer">Wellness Rituals</button>
            </div>
          </div>

          {/* Col 3: Enquiries */}
          <div className="space-y-4">
            <h4 className="font-display text-xs tracking-widest text-luxury-gold-dark font-bold uppercase">
              Initiatives
            </h4>
            <p className="text-xs text-gray-500 leading-relaxed">
              Interested in speaking with a project architect? Submit a formal request to begin strategy mapping.
            </p>
            <button
              onClick={onEnquireClick}
              className="inline-flex items-center space-x-2 text-xs text-luxury-gold-dark border-b border-luxury-gold-dark/30 hover:border-luxury-gold pb-1 transition-all uppercase font-medium tracking-widest cursor-pointer"
            >
              <span>CONNECT SECURELY</span>
            </button>
          </div>
        </div>

        {/* Bottom footer row */}
        <div className="pt-8 border-t border-gray-200/40 flex flex-col md:flex-row items-center justify-between text-gray-450 text-[11px] tracking-widest uppercase gap-4">
          <div>
            © 2024 CreatorBrand. All rights reserved.
          </div>
          <div className="flex items-center space-x-6 text-gray-500">
            <span>market@creatorbrand.com</span>
            <button 
              onClick={scrollToTop} 
              className="inline-flex items-center space-x-1.5 hover:text-luxury-gold-dark transition-colors duration-200 text-gray-500 hover:scale-105 transform cursor-pointer"
              title="Scroll to Top"
            >
              <span>TOP</span>
              <ArrowUp className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

      </div>
    </footer>
  );
}
