import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ArrowRight, 
  Lightbulb, 
  Palette, 
  Factory, 
  Globe, 
  ChevronDown, 
  ChevronUp, 
  FileText, 
  Sliders, 
  Sparkles, 
  Lock
} from 'lucide-react';
import { PageId, ServiceItem, CategoryCard, FAQItem } from '../types';
import Logo from './Logo';
import Footer from './Footer';

// Import newly generated brand narrative images matching user specification
import productIdeasImg from '../assets/images/product_ideas_workspace_1781775118508.jpg';
import customDesignImg from '../assets/images/custom_design_branding_ipad_1781775134773.jpg';
import manufacturingImg from '../assets/images/manufacturing_pottery_hands_1781775147317.jpg';
import globalReachImg from '../assets/images/global_reach_harbor_sunset_1781775161680.jpg';

interface HomeViewProps {
  setCurrentPage: (page: PageId) => void;
  onEnquireClick: (brandType?: string) => void;
}

export default function HomeView({ setCurrentPage, onEnquireClick }: HomeViewProps) {
  // FAQ state
  const [openFaq, setOpenFaq] = useState<string | null>(null);

  // Expanded services state
  const [expandedService, setExpandedService] = useState<string | null>(null);

  // Sourced Services Data (corrected spellings and set custom photos)
  const services: ServiceItem[] = [
    {
      id: 'product-ideas',
      title: 'PRODUCT IDEAS',
      subtitle: 'BRAINSTORMING & MARKET VALIDATION',
      description: 'We translate your audience metrics and creative persona into verified product concepts. Through strict cohort analysis and rigorous market validation, we prove demands before pouring raw materials.',
      image: productIdeasImg
    },
    {
      id: 'custom-design',
      title: 'CUSTOM DESIGN',
      subtitle: 'BRANDING, PACKAGING & UI',
      description: 'Creative architects create customized visual books, high-gauge paper boxes, and premium tactile bottles. This ensures your online brand connects seamlessly with a physical masterpiece.',
      image: customDesignImg
    },
    {
      id: 'manufacturing',
      title: 'MANUFACTURING',
      subtitle: 'SOURCING TRUSTED SUPPLIERS',
      description: 'Through our vetted global network, we bypass standard supply rings. We connect you with verified natural beauty labs, boutique Japanese ceramic kilns, and elite tailored sewing houses.',
      image: manufacturingImg
    },
    {
      id: 'global-reach',
      title: 'GLOBAL REACH',
      subtitle: 'LOGISTICS & FULFILLMENT',
      description: 'Your supply lines are managed by experts. From custom custom import clearance, duty auditing, temperature-stable warehousing, to express home parcel dispatch globally.',
      image: globalReachImg
    }
  ];

  // Grid Category Cards
  const categories: CategoryCard[] = [
    {
      id: 'beauty',
      name: 'BEAUTY',
      subtitle: 'PREMIUM SKINCARE & ESSENTIALS',
      image: 'https://images.unsplash.com/photo-1612817288484-6f916006741a?q=80&w=600&auto=format&fit=crop',
      accentTitle: 'SKINCARE'
    },
    {
      id: 'fitness',
      name: 'FITNESS',
      subtitle: 'PERFORMANCE EQUIPMENT & Activewear',
      image: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?q=80&w=600&auto=format&fit=crop',
      accentTitle: 'PERFORMANCE'
    },
    {
      id: 'home-collection',
      name: 'HOME',
      subtitle: 'MINIMALIST RAW DECOR & CERAMICS',
      image: 'https://images.unsplash.com/photo-1513519245088-0e12902e5a38?q=80&w=600&auto=format&fit=crop',
      accentTitle: 'MINIMALIST DECOR'
    },
    {
      id: 'apparel',
      name: 'APPAREL',
      subtitle: 'FINE SILK & SWEAT CAPSULE',
      image: 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?q=80&w=600&auto=format&fit=crop',
      accentTitle: 'SILK CAPSULE'
    },
    {
      id: 'tech',
      name: 'TECH',
      subtitle: 'LEATHER CASING & CHARGING DOCKS',
      image: 'https://images.unsplash.com/photo-1585776245991-cf89dd7fc73a?q=80&w=600&auto=format&fit=crop',
      accentTitle: 'ESSENTIALS'
    },
    {
      id: 'wellness',
      name: 'WELLNESS',
      subtitle: 'HOLISTIC SUPPLEMENTS & RITUALS',
      image: 'https://images.unsplash.com/photo-1540555700478-4be289fbecef?q=80&w=600&auto=format&fit=crop',
      accentTitle: 'RITUALS'
    }
  ];

  // FAQ Sourced Answers & questions
  const faqs: FAQItem[] = [
    {
      id: 'faq-1',
      question: 'WHAT IS THE CREATORBRAND LUXURY INITIATIVE?',
      answer: 'CreatorBrand is a specialized private agency that partners with elite digital creators to conceptualize, design, manufacture, and distribute luxury physical products. Unlike traditional e-commerce aggregators, we establish custom, high-end design houses owned by the creators with support from sovereign supply lines.'
    },
    {
      id: 'faq-2',
      question: 'HOW DO YOU ENSURE PRODUCT QUALITY STANDARDS?',
      answer: 'We operate physically within our source areas. Every batch of skincare undergoes rigorous dermatological checks, ceramics are thrown by third-generation kiln owners, and our apparel utilizes only premium sustainable fibers such as high-momme silk and heavy organic cotton.'
    },
    {
      id: 'faq-3',
      question: 'WHAT ACCOUNTS OR AUDIENCE SCALE DO YOU WORK WITH?',
      answer: 'We curate our relationships carefully, focusing on premium aesthetic creators with active engagement metrics. Our system supports high-density customized boutique batches to sustain exclusive luxury limits.'
    },
    {
      id: 'faq-4',
      question: 'WHAT LOGISTICS GEOGRAPHIES ARE SUPPORTED?',
      answer: 'Our physical warehousing hubs reside in Western Europe, East Asia, and North America. This geographic layout allows fully managed duty clearance and express courier parcel delivery to major cities worldwide within 3-5 business days.'
    }
  ];

  const handleScrollToCategories = () => {
    const el = document.getElementById('categories');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const toggleFaq = (id: string) => {
    setOpenFaq(openFaq === id ? null : id);
  };

  return (
    <div className="bg-luxury-linen min-h-screen text-luxury-charcoal">
      {/* ----------------- SECTION 1 - HERO ----------------- */}
      <section 
        id="hero" 
        className="relative min-h-[90vh] flex items-center justify-center overflow-hidden bg-luxury-linen"
      >
        {/* Deep parallax high-end backdrop image */}
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.unsplash.com/photo-1600585154340-be6161a56a0c?q=80&w=1600&auto=format&fit=crop" 
            alt="CreatorBrand Luxury Room" 
            className="w-full h-full object-cover opacity-70 object-center scale-105 transform transition-transform duration-10000"
            referrerPolicy="no-referrer"
          />
          {/* Multi-layered soft light gradient for perfect contrast */}
          <div className="absolute inset-0 bg-gradient-to-t from-luxury-linen via-luxury-linen/80 to-white/95" />
        </div>

        {/* Hero Content Block */}
        <div className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-8 py-20">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1 }}
            className="space-y-6"
          >
            {/* Logo in hero section */}
            <div className="flex justify-center mb-4">
              <Logo className="h-16 text-luxury-dark max-w-[240px]" />
            </div>

            <p className="text-[11px] sm:text-xs tracking-[0.4em] text-luxury-gold-dark uppercase font-bold">
              THE SOVEREIGN DESTINATION FOR ELITE CREATORS
            </p>

            <h1 className="font-display text-4xl sm:text-6xl md:text-7xl font-bold tracking-[0.1em] text-luxury-dark leading-tight max-w-4xl mx-auto uppercase">
              CREATORBRAND
            </h1>

            <p className="font-serif text-sm sm:text-lg text-gray-600 max-w-xl mx-auto italic leading-relaxed">
              "Translating digital influence into enduring luxury portfolios."
            </p>
          </motion.div>

          {/* Action buttons */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5, duration: 1 }}
            className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-6"
            id="hero-actions"
          >
            <button
              onClick={handleScrollToCategories}
              className="w-full sm:w-auto px-10 py-5 bg-transparent border border-luxury-gold-dark hover:bg-luxury-gold-dark hover:text-white text-xs font-semibold tracking-widest text-luxury-gold-dark uppercase rounded-none cursor-pointer transition-all duration-300 transform hover:scale-[1.02]"
              id="hero-discover-btn"
            >
              DISCOVER
            </button>
            <button
              onClick={() => onEnquireClick('Home')}
              className="w-full sm:w-auto px-10 py-5 bg-luxury-dark hover:bg-luxury-gold-dark text-white text-xs font-semibold tracking-widest uppercase rounded-none cursor-pointer transition-all duration-300 transform hover:scale-[1.02] shadow-sm hover:shadow-md"
              id="hero-enquire-btn"
            >
              BOOK PARTNERSHIP CALL
            </button>
          </motion.div>
        </div>

        {/* Elegant scroll indicator */}
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 flex flex-col items-center space-y-2 animate-bounce cursor-pointer opacity-85" onClick={handleScrollToCategories}>
          <span className="text-[9px] tracking-widest uppercase text-luxury-gold-dark font-medium">SCROLL DOWN</span>
          <div className="w-[1px] h-10 bg-luxury-gold-dark/40" />
        </div>
      </section>

      {/* ----------------- SECTION 2 - SERVICES ----------------- */}
      <section 
        id="services" 
        className="py-24 bg-white border-t border-b border-gray-200/40 relative animate-fadeIn"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          {/* Section Header */}
          <div className="text-center space-y-4 mb-20">
            <span className="text-[11px] tracking-[0.3em] text-luxury-gold-dark uppercase font-semibold">SOVEREIGN CAPABILITIES</span>
            <h2 className="font-display text-3xl sm:text-4xl tracking-widest text-luxury-dark uppercase font-bold">
              OUR COMPLETE SERVICE SUITE
            </h2>
            <div className="w-16 h-[1px] bg-luxury-gold-dark mx-auto mt-4" />
          </div>

          {/* Cards vertical stack list container */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-12">
            {services.map((svc, idx) => {
              const isExt = expandedService === svc.id;
              return (
                <div 
                  key={svc.id}
                  className="bg-luxury-linen/40 border border-gray-200/50 hover:border-luxury-gold-dark/40 p-8 flex flex-col justify-between transition-all duration-300 hover:shadow-lg rounded-none"
                  id={`service-${svc.id}`}
                >
                  <div className="space-y-6">
                    {/* Visual Card Image */}
                    <div className="w-full h-56 overflow-hidden relative group">
                      <img 
                        src={svc.image} 
                        alt={svc.title} 
                        className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute inset-0 bg-black/10" />
                      <div className="absolute top-4 left-4 bg-white px-3 py-1.5 border border-gray-200/80 flex items-center space-x-1.5">
                        {idx === 0 && <Lightbulb className="w-3.5 h-3.5 text-luxury-gold-dark" />}
                        {idx === 1 && <Palette className="w-3.5 h-3.5 text-luxury-gold-dark" />}
                        {idx === 2 && <Factory className="w-3.5 h-3.5 text-luxury-gold-dark" />}
                        {idx === 3 && <Globe className="w-3.5 h-3.5 text-luxury-gold-dark" />}
                        <span className="text-[9px] tracking-widest text-luxury-dark font-bold uppercase">0{idx + 1}</span>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <h3 className="font-display text-xl tracking-wider text-luxury-dark uppercase font-bold">{svc.title}</h3>
                      <p className="text-[10px] tracking-widest text-luxury-gold-dark font-medium uppercase">{svc.subtitle}</p>
                    </div>

                    <p className="text-gray-600 text-xs sm:text-sm tracking-wide leading-relaxed">
                      {svc.description}
                    </p>
                  </div>

                  <div className="pt-6 border-t border-gray-200/60 mt-6 flex items-center justify-between">
                    <button
                      onClick={() => setExpandedService(isExt ? null : svc.id)}
                      className="text-[11px] tracking-widest text-luxury-gold-dark hover:text-luxury-dark uppercase font-semibold flex items-center space-x-1.5 group cursor-pointer"
                    >
                      <span>{isExt ? 'COLLAPSE DETAILS' : 'DISCOVER SPECIFICS'}</span>
                      <ArrowRight className="w-3.5 h-3.5 transform group-hover:translate-x-1 transition-transform" />
                    </button>
                    {isExt && <span className="text-[9px] text-luxury-gold-dark tracking-widest font-semibold">ACTIVE PORTFOLIO</span>}
                  </div>

                  {/* Expanded block with motion */}
                  <AnimatePresence>
                    {isExt && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        exit={{ opacity: 0, height: 0 }}
                        transition={{ duration: 0.3 }}
                        className="overflow-hidden mt-4 pt-4 border-t border-gray-200/60 text-xs text-gray-700 space-y-3 bg-white p-4 border border-gray-100"
                      >
                        <p className="font-serif italic text-luxury-gold-dark">
                          "Pragmatic physical execution backed by master digital integration."
                        </p>
                        <div className="space-y-1 text-[11px] text-gray-600">
                          {svc.id === 'product-ideas' && (
                            <>
                              <div>• Audience sentiment matrix mapping</div>
                              <div>• Product margin matrix proving</div>
                              <div>• Verified prototyping cohort focus runs</div>
                            </>
                          )}
                          {svc.id === 'custom-design' && (
                            <>
                              <div>• Proprietary 3D vessel render blocks</div>
                              <div>• Premium cardboard stock paper selection</div>
                              <div>• Complete storefront vector integrations</div>
                            </>
                          )}
                          {svc.id === 'manufacturing' && (
                            <>
                              <div>• FDA-certified organic laboratory agreements</div>
                              <div>• ISO-standard mechanical validation runs</div>
                              <div>• Single-source clean ingredient verification</div>
                            </>
                          )}
                          {svc.id === 'global-reach' && (
                            <>
                              <div>• Smart API system integrations</div>
                              <div>• Custom VAT & international tax clearing</div>
                              <div>• 24-hour physical pack auditing loops</div>
                            </>
                          )}
                        </div>
                        <button
                          onClick={() => onEnquireClick(svc.title)}
                          className="w-full mt-2 py-3 border border-luxury-gold-dark text-luxury-gold-dark hover:bg-luxury-gold-dark hover:text-white text-[10px] tracking-widest uppercase transition-all duration-300 rounded-none font-bold"
                        >
                          Request Consultation
                        </button>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              );
            })}
          </div>

        </div>
      </section>

      {/* ----------------- SECTION 3 - CATEGORIES CONNECTION GRID ----------------- */}
      <section 
        id="categories" 
        className="py-24 bg-luxury-linen relative"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          {/* Section Header */}
          <div className="text-center space-y-4 mb-20">
            <span className="text-[11px] tracking-[0.3em] text-luxury-gold-dark uppercase font-semibold text-center block">THE GALLERY COLLECTION</span>
            <h2 className="font-display text-3xl sm:text-4xl tracking-widest text-luxury-dark uppercase font-bold text-center">
              SELECT YOUR BRAND VERTICAL
            </h2>
            <p className="text-gray-600 text-xs sm:text-sm tracking-wide leading-relaxed max-w-xl mx-auto">
              Please choose an editorial brand category card to review its corresponding live case study profile containing vision, collection assets, and manufacturing flows.
            </p>
            <div className="w-16 h-[1px] bg-luxury-gold-dark mx-auto mt-4" />
          </div>

          {/* Grid Layout of 6 Category cards ( Beauty, Fitness, Home, Apparel, Tech, Wellness ) */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
            {categories.map((cat, idx) => (
              <div 
                key={cat.id}
                onClick={() => {
                  setCurrentPage(cat.id);
                  window.scrollTo({ top: 0, behavior: 'instant' });
                }}
                className="group relative h-[380px] bg-white border border-gray-200/40 cursor-pointer overflow-hidden flex flex-col justify-end p-8 transition-all duration-500 shadow-md hover:shadow-xl"
                id={`category-card-${cat.id}`}
              >
                {/* Background image & overlay */}
                <div className="absolute inset-0 z-0">
                  <img 
                    src={cat.image} 
                    alt={cat.name} 
                    className="w-full h-full object-cover grayscale brightness-95 group-hover:grayscale-0 group-hover:scale-105 transition-all duration-700"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/35 to-transparent group-hover:via-black/50 transition-all duration-500" />
                </div>

                {/* Card borders hover highlight */}
                <div className="absolute inset-4 border border-luxury-gold-dark/0 group-hover:border-luxury-gold-dark/20 transition-all duration-500 pointer-events-none" />

                {/* Content over image */}
                <div className="relative z-10 space-y-3">
                  <div className="flex items-center space-x-2">
                    <span className="text-[9px] tracking-wider text-luxury-gold-dark uppercase px-2 py-0.5 bg-black/50 border border-luxury-gold-dark/20 font-bold text-white">
                      {cat.accentTitle}
                    </span>
                    <div className="h-[1px] w-8 bg-luxury-gold-dark/40 group-hover:w-16 transition-all duration-500" />
                  </div>
                  <h3 className="font-display text-2xl tracking-widest text-white font-bold group-hover:text-luxury-gold-light transition-colors">
                    {cat.name}
                  </h3>
                  <p className="text-[10px] tracking-widest text-gray-200 group-hover:text-white transition-colors uppercase">
                    {cat.subtitle}
                  </p>
                  
                  <div className="pt-2 flex items-center space-x-2 text-[10px] font-bold tracking-widest text-luxury-gold-light opacity-0 group-hover:opacity-100 transform translate-y-2 group-hover:translate-y-0 transition-all duration-300">
                    <span>VIEW CASE PROFILE</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </div>
                </div>
              </div>
            ))}
          </div>

        </div>
      </section>

      {/* ----------------- SECTION 4 - PROCESS, CASES, FAQ, FOOTER ----------------- */}
      <section 
        id="process" 
        className="py-24 bg-white border-t border-gray-200/40 relative"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-32">
          
          {/* Subsection 4a: The 5-Step Process */}
          <div className="space-y-16">
            <div className="text-center space-y-4">
              <span className="text-[11px] tracking-[0.3em] text-luxury-gold-dark uppercase font-semibold block text-center">CREATION ROADMAP</span>
              <h2 className="font-display text-3xl sm:text-4xl tracking-widest text-luxury-dark uppercase font-bold text-center">
                THE FIVE-STEP PROTOCOL
              </h2>
              <div className="w-16 h-[1px] bg-luxury-gold-dark mx-auto mt-4" />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-5 gap-8">
              {[
                { step: '1', title: 'DISCOVERY CALL', desc: 'Custom diagnostic review of reach, analytics, and primary visual interests.' },
                { step: '2', title: 'STRATEGY & DESIGN', desc: 'Bespoke custom packaging rendering and exact materials selection.' },
                { step: '3', title: 'DEVELOPMENT', desc: 'Custom batch chemical and physical prototyping with laboratory experts.' },
                { step: '4', title: 'PRODUCTION', desc: 'Manufacturing with sovereign suppliers under rigid quality check loops.' },
                { step: '5', title: 'SCALE & GROW', desc: 'Fully-synced logistics channels globally with automated reorder tags.' }
              ].map((p, idx) => (
                <div 
                  key={p.step}
                  className="bg-luxury-linen/30 border-l-2 border-luxury-gold-dark/30 hover:border-luxury-gold-dark p-6 space-y-4 hover:bg-white transition-all duration-300"
                  id={`process-step-${p.step}`}
                >
                  <div className="font-display text-4xl text-luxury-gold-dark font-bold select-none opacity-50 hover:opacity-100 transition-opacity">
                    0{p.step}
                  </div>
                  <h4 className="font-display text-xs tracking-wider font-bold text-luxury-dark uppercase">
                    {p.title}
                  </h4>
                  <p className="text-[11px] sm:text-xs text-gray-600 tracking-wide leading-relaxed">
                    {p.desc}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Subsection 4b: Previews Showcase */}
          <div className="space-y-16 pt-8">
            <div className="text-center space-y-4">
              <span className="text-[11px] tracking-[0.3em] text-luxury-gold-dark uppercase font-semibold block text-center">CLIENT CASES</span>
              <h2 className="font-display text-3xl sm:text-4xl tracking-widest text-luxury-dark uppercase font-bold text-center">
                ACTIVE COHORTS SHOWCASE
              </h2>
              <div className="w-16 h-[1px] bg-luxury-gold-dark mx-auto mt-4" />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
              {/* Case 1 */}
              <div 
                onClick={() => { setCurrentPage('beauty'); window.scrollTo({ top: 0, behavior: 'instant' }); }}
                className="group cursor-pointer space-y-6"
                id="showcase-case-1"
              >
                <div className="relative h-64 overflow-hidden border border-gray-200/50">
                  <img 
                    src="https://images.unsplash.com/photo-1608248597279-f99d160bfcbc?q=80&w=800" 
                    alt="LUZATER SKincare" 
                    className="w-full h-full object-cover grayscale brightness-90 group-hover:scale-105 group-hover:grayscale-0 transition-all duration-500"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-85" />
                  <div className="absolute bottom-6 left-6 text-left">
                    <span className="text-[9px] tracking-wider text-white uppercase bg-black/50 px-2 py-1 border border-white/20 font-bold">BEAUTY VERTICAL</span>
                  </div>
                </div>
                <div className="space-y-2 text-left">
                  <h4 className="font-display text-lg tracking-widest text-luxury-dark group-hover:text-luxury-gold-dark transition-colors uppercase font-bold">LUZATER SKINCARE LINE</h4>
                  <p className="text-[11px] text-gray-600 tracking-wider max-w-md leading-relaxed">
                    Sovereign cosmetic capsules customized seamlessly for micro-audiences, utilizing luxury high-contrast heavy glass.
                  </p>
                </div>
              </div>

              {/* Case 2 */}
              <div 
                onClick={() => { setCurrentPage('apparel'); window.scrollTo({ top: 0, behavior: 'instant' }); }}
                className="group cursor-pointer space-y-6"
                id="showcase-case-2"
              >
                <div className="relative h-64 overflow-hidden border border-gray-200/50">
                  <img 
                    src="https://images.unsplash.com/photo-1517841905240-472988babdf9?q=80&w=800" 
                    alt="Influencer Apparel Capsule" 
                    className="w-full h-full object-cover grayscale brightness-90 group-hover:scale-105 group-hover:grayscale-0 transition-all duration-500"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-85" />
                  <div className="absolute bottom-6 left-6 text-left">
                    <span className="text-[9px] tracking-wider text-white uppercase bg-black/50 px-2 py-1 border border-white/20 font-bold">APPAREL COHORT</span>
                  </div>
                </div>
                <div className="space-y-2 text-left">
                  <h4 className="font-display text-lg tracking-widest text-luxury-dark group-hover:text-luxury-gold-dark transition-colors uppercase font-bold">INFLUENCER APPAREL DROP</h4>
                  <p className="text-[11px] text-gray-600 tracking-wider max-w-md leading-relaxed">
                    Bespoke loose-fitting pajamas engineered with heavyweight pure sustainable linen, spun exclusively in custom palettes.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Subsection 4c: FAQ Accordion */}
          <div id="faq" className="space-y-16 pt-8">
            <div className="text-center space-y-4">
              <span className="text-[11px] tracking-[0.3em] text-luxury-gold-dark uppercase font-semibold block text-center">ACQUISITIVE INTENT</span>
              <h2 className="font-display text-3xl sm:text-4xl tracking-widest text-luxury-dark uppercase font-bold text-center">
                FREQUENTLY PROMPTED QUESTIONS
              </h2>
              <div className="w-16 h-[1px] bg-luxury-gold-dark mx-auto mt-4" />
            </div>

            <div className="max-w-3xl mx-auto divide-y divide-gray-200/60 bg-white p-6 md:p-8 border border-gray-150">
              {faqs.map((faq) => {
                const isOpen = openFaq === faq.id;
                return (
                  <div key={faq.id} className="py-5" id={faq.id}>
                    <button
                      onClick={() => toggleFaq(faq.id)}
                      className="w-full flex items-center justify-between text-left text-xs sm:text-sm tracking-widest uppercase font-bold hover:text-luxury-gold-dark transition-colors duration-200 cursor-pointer text-luxury-dark"
                    >
                      <span>{faq.question}</span>
                      {isOpen ? (
                        <ChevronUp className="w-4 h-4 text-luxury-gold-dark flex-shrink-0" />
                      ) : (
                        <ChevronDown className="w-4 h-4 text-gray-400 flex-shrink-0" />
                      )}
                    </button>
                    <AnimatePresence>
                      {isOpen && (
                        <motion.div
                          initial={{ opacity: 0, height: 0 }}
                          animate={{ opacity: 1, height: 'auto' }}
                          exit={{ opacity: 0, height: 0 }}
                          transition={{ duration: 0.2 }}
                          className="overflow-hidden"
                        >
                          <p className="mt-4 text-xs sm:text-[13px] text-gray-600 tracking-wide leading-relaxed font-serif">
                            {faq.answer}
                          </p>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                );
              })}
            </div>
          </div>

        </div>
      </section>

      {/* Global integrated footer element */}
      <Footer setCurrentPage={setCurrentPage} onEnquireClick={() => onEnquireClick()} />
    </div>
  );
}
