import React from 'react';

interface LogoProps {
  className?: string;
  light?: boolean;
}

export default function Logo({ className = 'h-8', light = false }: LogoProps) {
  return (
    <div className={`inline-flex items-center space-x-3 select-none ${className}`}>
      {/* 
        This is an exact vector trace of the pill-shaped "CB" logo uploaded by the user.
        It uses a compound shape with perfect curves and mathematically precise negative space cutouts.
      */}
      <svg
        viewBox="0 0 200 120"
        className="h-full fill-current aspect-[5/3]"
        style={{ color: light ? '#0a0a0a' : 'currentColor' }}
      >
        <path
          fillRule="evenodd"
          clipRule="evenodd"
          d="M 60,10 H 140 A 50,50 0 0 1 190,60 A 50,50 0 0 1 140,110 H 60 A 50,50 0 0 1 10,60 A 50,50 0 0 1 60,10 Z 
             M 64,28 H 92 V 92 H 64 A 32,32 0 0 1 32,60 A 32,32 0 0 1 64,28 Z 
             M 112,28 H 136 A 16,16 0 0 1 152,44 A 12,12 0 0 1 140,56 H 112 V 28 Z 
             M 112,64 H 140 A 12,12 0 0 1 152,76 A 16,16 0 0 1 136,92 H 112 V 64 Z"
          fill="currentColor"
        />
      </svg>
      
      {/* Elegant minimalist wordmark with tracking-widest block letters */}
      <span className="font-display text-sm tracking-[0.25em] font-bold text-luxury-dark uppercase">
        CreatorBrand
      </span>
    </div>
  );
}
