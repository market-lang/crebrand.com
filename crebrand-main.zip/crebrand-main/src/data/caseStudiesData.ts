import { CaseStudy } from '../types';

export const caseStudiesData: Record<string, CaseStudy> = {
  'beauty': {
    id: 'beauty',
    title: 'Beauty / Skincare',
    subtitle: 'EDITORIAL CASE STUDY: SKINCARE',
    heroImage: 'https://images.unsplash.com/photo-1608248597279-f99d160bfcbc?q=80&w=1200&auto=format&fit=crop',
    visionText: 'The formulation of elite creator-led skincare marks a sovereign leap in modern physical branding. By stripping away generic filler compounds and building with pure sun-baked bio-active elements, we realize a product that serves as both a high-efficacy regimen and a beautifully tailored sculptural bath fixture.',
    visionImage: 'https://images.unsplash.com/photo-1612817288484-6f916006741a?q=80&w=800&auto=format&fit=crop',
    collectionText: 'Our skincare collection is customized with warm tones and tactile ivory sand-blasted glass jars, representing premium minimalist bath artifacts that are beautiful in any natural morning light.',
    collectionImage: 'https://images.unsplash.com/photo-1601049676099-e7ed07d825b0?q=80&w=800&auto=format&fit=crop',
    products: [
      {
        name: 'RADIANT SERUM',
        image: 'https://images.unsplash.com/photo-1620916566398-39f1143ab7be?q=80&w=600&auto=format&fit=crop',
        description: 'Vitamins C + E botanical blend housed in heavy pharmaceutical amber vessels.'
      },
      {
        name: 'HYDRATING CREAM',
        image: 'https://images.unsplash.com/photo-1601049541289-9b1b7bbbfe19?q=80&w=600&auto=format&fit=crop',
        description: 'Rich cloud-whipped lipids combined with wild organic lavender essence.'
      },
      {
        name: 'NOURISHING OIL',
        image: 'https://images.unsplash.com/photo-1608248597279-f99d160bfcbc?q=80&w=600&auto=format&fit=crop',
        description: 'Cold-pressed botanical skin oil for a pristine midnight cellular reset.'
      },
      {
        name: 'EXFOLIATING CLEANSER',
        image: 'https://images.unsplash.com/photo-1556228720-195a672e8a03?q=80&w=600&auto=format&fit=crop',
        description: 'Superfine mineral-infused cleanser designed with gentle organic fruit acids.'
      }
    ],
    processSteps: [
      { name: 'RADIANT SERUM', image: 'https://images.unsplash.com/photo-1620916566398-39f1143ab7be?q=80&w=300&auto=format&fit=crop' },
      { name: 'HYDRATING CREAM', image: 'https://images.unsplash.com/photo-1601049541289-9b1b7bbbfe19?q=80&w=300&auto=format&fit=crop' },
      { name: 'NOURISHING OIL', image: 'https://images.unsplash.com/photo-1608248597279-f99d160bfcbc?q=80&w=300&auto=format&fit=crop' },
      { name: 'EXFOLIATING CLEANSER', image: 'https://images.unsplash.com/photo-1556228720-195a672e8a03?q=80&w=300&auto=format&fit=crop' }
    ]
  },
  'fitness': {
    id: 'fitness',
    title: 'Fitness / Performance Line',
    subtitle: 'CASE STUDY: FITNESS PERFORMANCE LINE',
    heroImage: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?q=80&w=1200&auto=format&fit=crop',
    visionText: 'Physical energy demands high-discipline gear that looks exceptional. We re-engineered fitness gear with muted brass coatings, high-gauge double-knitted loops, and dense composite weights. By unifying technical utility with modern interior styling, we created fitness essentials that deserve to be showcased in upscale living spaces rather than hidden in dark lockers.',
    visionImage: 'https://images.unsplash.com/photo-1541534741688-6078c6bfb5c5?q=80&w=800&auto=format&fit=crop',
    collectionText: 'The activewear collection couples structural neutral drapes with robust modern engineering for creators focused on active living and elite performance.',
    collectionImage: 'https://images.unsplash.com/photo-1518310383802-640c2de311b2?q=80&w=800&auto=format&fit=crop',
    products: [
      {
        name: 'DESIGNER RESISTANCE BANDS',
        image: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?q=80&w=600&auto=format&fit=crop',
        description: 'Woven latex-free bands in sand and slate palettes with gold hardware connectors.'
      },
      {
        name: 'MINIMALIST SHAKER BOTTLE',
        image: 'https://images.unsplash.com/photo-1574680096145-d05b474e2155?q=80&w=600&auto=format&fit=crop',
        description: 'Double-walled insulated steel container in clean matte black finish.'
      }
    ],
    processSteps: [
      { name: 'WORKOUT', image: 'https://images.unsplash.com/photo-1541534741688-6078c6bfb5c5?q=80&w=300&auto=format&fit=crop' },
      { name: 'PROCESS', image: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?q=80&w=300&auto=format&fit=crop' },
      { name: 'PROCESS', image: 'https://images.unsplash.com/photo-1574680096145-d05b474e2155?q=80&w=300&auto=format&fit=crop' },
      { name: 'SPELL PRODUCTS', image: 'https://images.unsplash.com/photo-1518310383802-640c2de311b2?q=80&w=300&auto=format&fit=crop' }
    ]
  },
  'home-collection': {
    id: 'home-collection',
    title: 'Home Collection',
    subtitle: 'CASE STUDY: HOME COLLECTION',
    heroImage: 'https://images.unsplash.com/photo-1513519245088-0e12902e5a38?q=80&w=1200&auto=format&fit=crop',
    visionText: 'The home is a personal gallery of curated thoughts. We worked with master potter guilds in Ishikawa and ancient weaving houses in Northern Europe to craft clean minimalist ceramic vases, custom hand-poured candle wax, and thick raw linen throws. Each piece represents a sun-baked tactile luxury item for the mindful creator home.',
    visionImage: 'https://images.unsplash.com/photo-1603006905003-be475563bc59?q=80&w=800&auto=format&fit=crop',
    collectionText: 'Our home decor capsules feature authentic local clays and ancient plant fibers, styled with natural gold highlights to represent pure, quiet luxury.',
    collectionImage: 'https://images.unsplash.com/photo-1540555700478-4be289fbecef?q=80&w=800&auto=format&fit=crop',
    products: [
      {
        name: 'SCENTED CANDLE',
        image: 'https://images.unsplash.com/photo-1603006905003-be475563bc59?q=80&w=600&auto=format&fit=crop',
        description: 'Soy bean wax infused with rare hinoki forest cedarwood and sweet tobacco.'
      },
      {
        name: 'LINEN THROW',
        image: 'https://images.unsplash.com/photo-1540555700478-4be289fbecef?q=80&w=600&auto=format&fit=crop',
        description: 'Raw-edged heavy organic linen spun and sun-bleached on rural looms.'
      },
      {
        name: 'CERAMIC VASE',
        image: 'https://images.unsplash.com/photo-1581781894090-a5c9d080e111?q=80&w=600&auto=format&fit=crop',
        description: 'Wheel-thrown porous clay slip and natural glaze finish for individual texture.'
      },
      {
        name: 'DIFFUSER SET',
        image: 'https://images.unsplash.com/photo-1513519245088-0e12902e5a38?q=80&w=600&auto=format&fit=crop',
        description: 'Terracotta vessel paired with naturally harvested wild cane diffusing reeds.'
      }
    ],
    processSteps: [
      { name: 'SCENTED CANDLE', image: 'https://images.unsplash.com/photo-1603006905003-be475563bc59?q=80&w=300&auto=format&fit=crop' },
      { name: 'LINEN THROW', image: 'https://images.unsplash.com/photo-1540555700478-4be289fbecef?q=80&w=300&auto=format&fit=crop' },
      { name: 'CERAMIC VASE', image: 'https://images.unsplash.com/photo-1581781894090-a5c9d080e111?q=80&w=300&auto=format&fit=crop' },
      { name: 'DIFFUSER SET', image: 'https://images.unsplash.com/photo-1513519245088-0e12902e5a38?q=80&w=300&auto=format&fit=crop' }
    ]
  },
  'apparel': {
    id: 'apparel',
    title: 'Apparel Capsule',
    subtitle: 'CASE STUDY: APPAREL CAPSULE',
    heroImage: 'https://images.unsplash.com/photo-1508427953056-b00b8d78ec65?q=80&w=1200&auto=format&fit=crop',
    visionText: 'The skin desires tactile honesty. Our apparel capsule targets daily ritual apparel constructed entirely of 32-momme pure mulberry silk and extra-heavy organic cotton. By working with direct sustainable looms and utilizing custom hand-drawn pattern drafts, we render a sensory wardrobe emphasizing drape, weight, and extreme neutral flow.',
    visionImage: 'https://images.unsplash.com/photo-1485968579580-b6d095142e6e?q=80&w=800&auto=format&fit=crop',
    collectionText: 'Raw, neutral-dyed silk loungewear and heavy-fleece tailoring developed for elite creators who require simple, powerful visual consistency.',
    collectionImage: 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?q=80&w=800&auto=format&fit=crop',
    products: [
      {
        name: 'HOODIE',
        image: 'https://images.unsplash.com/photo-1556905055-8f358a7a47b2?q=80&w=600&auto=format&fit=crop',
        description: '600gsm combed organic cotton with unbranded drooped drop-shoulder seams.'
      },
      {
        name: 'SILK TOP',
        image: 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?q=80&w=600&auto=format&fit=crop',
        description: 'Premium raw sand-washed pure mulberry silk slip with delicate gold straps.'
      },
      {
        name: 'LOUNGEWEAR SET',
        image: 'https://images.unsplash.com/photo-1512436991641-6745cdb1723f?q=80&w=600&auto=format&fit=crop',
        description: 'Two-piece matching relaxed loungewear set crafted from warm organic fibers.'
      }
    ],
    processSteps: [
      { name: 'HOODIE', image: 'https://images.unsplash.com/photo-1556905055-8f358a7a47b2?q=80&w=300&auto=format&fit=crop' },
      { name: 'SILK TOP', image: 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?q=80&w=300&auto=format&fit=crop' },
      { name: 'LOUNGEWEAR SET', image: 'https://images.unsplash.com/photo-1512436991641-6745cdb1723f?q=80&w=300&auto=format&fit=crop' }
    ]
  },
  'tech': {
    id: 'tech',
    title: 'Tech Essentials',
    subtitle: 'CASE STUDY: TECH ESSENTIALS',
    heroImage: 'https://images.unsplash.com/photo-1585776245991-cf89dd7fc73a?q=80&w=1200&auto=format&fit=crop',
    visionText: 'The tools of creation deserve noble protection. This capsule converts daily digital essentials into custom objects of heavy-grain Tuscan leather and dark-anodized brushed aluminum. By wrapping our devices in warm, organic, hand-stitched leathers, we form an visual shield that patinas beautifully with every new campaign written.',
    visionImage: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?q=80&w=800&auto=format&fit=crop',
    collectionText: 'Elegant cellular protection and heavy-grain desk mats engineered with gold-plated metallic clasps for maximum detail precision.',
    collectionImage: 'https://images.unsplash.com/photo-1512290923902-8a9f81dc236c?q=80&w=800&auto=format&fit=crop',
    products: [
      {
        name: 'PREMIUM LEATHER PHONE CASE',
        image: 'https://images.unsplash.com/photo-1541807084-5c52b6b3adef?q=80&w=600&auto=format&fit=crop',
        description: 'Pebbled full-grain calfskin leather with integrated premium gold alloy triggers.'
      },
      {
        name: 'MINIMALIST LAPTOP SLEEVE',
        image: 'https://images.unsplash.com/photo-1512290923902-8a9f81dc236c?q=80&w=600&auto=format&fit=crop',
        description: 'Tough raw hide shielding padded with natural boiled Scandinavian sheep wool.'
      },
      {
        name: 'SLEEK CHARGING DOCK',
        image: 'https://images.unsplash.com/photo-1583863788434-e58a36330cf0?q=80&w=600&auto=format&fit=crop',
        description: 'Solid brass weighted platform engineered with safe Qi-standard smart induction.'
      },
      {
        name: 'LEATHER CABLE ORGANIZER',
        image: 'https://images.unsplash.com/photo-1522273400909-fd1a8f77637e?q=80&w=600&auto=format&fit=crop',
        description: 'Embossed leather strap with solid push-button compression studs.'
      }
    ],
    processSteps: [
      { name: 'PREMIUM LEATHER PHONE CASE', image: 'https://images.unsplash.com/photo-1541807084-5c52b6b3adef?q=80&w=300&auto=format&fit=crop' },
      { name: 'MINIMALIST LAPTOP SLEEVE', image: 'https://images.unsplash.com/photo-1512290923902-8a9f81dc236c?q=80&w=300&auto=format&fit=crop' },
      { name: 'SLEEK CHARGING DOCK', image: 'https://images.unsplash.com/photo-1583863788434-e58a36330cf0?q=80&w=300&auto=format&fit=crop' },
      { name: 'LEATHER CABLE ORGANIZER', image: 'https://images.unsplash.com/photo-1522273400909-fd1a8f77637e?q=80&w=300&auto=format&fit=crop' }
    ]
  },
  'wellness': {
    id: 'wellness',
    title: 'Wellness Rituals',
    subtitle: 'CASE STUDY: WELLNESS RITUALS',
    heroImage: 'https://images.unsplash.com/photo-1540555700478-4be289fbecef?q=80&w=1200&auto=format&fit=crop',
    visionText: 'Wellness is an intentional architecture of the internal landscape. We developed custom apothecary glass, cold-distilled ritual elixirs, and solid meditation bowls in Kyoto. By stripping away artificial synthetic bindings, your audience experiences pure, holistic botanical support designed to quiet noise and focus creation.',
    visionImage: 'https://images.unsplash.com/photo-1602143407151-7111542de6e8?q=80&w=800&auto=format&fit=crop',
    collectionText: 'Holistic dietary supplements, natural mineral mixtures, and solid raw healing brassware designed to cultivate deep everyday mindfulness.',
    collectionImage: 'https://images.unsplash.com/photo-1584017911766-d451b3d0e843?q=80&w=800&auto=format&fit=crop',
    products: [
      {
        name: 'SUPPLEMENTS',
        image: 'https://images.unsplash.com/photo-1584017911766-d451b3d0e843?q=80&w=600&auto=format&fit=crop',
        description: 'Vegan adaptogens and raw marine mineral complexes in beautiful glass pods.'
      },
      {
        name: 'RITUAL KITS',
        image: 'https://images.unsplash.com/photo-1602143407151-7111542de6e8?q=80&w=600&auto=format&fit=crop',
        description: 'Traditional smudge fibers, white quartz specimens, and handmade incense cones.'
      },
      {
        name: 'MEDITATION TOOLS',
        image: 'https://images.unsplash.com/photo-1518241353330-0f7941c2d9b5?q=80&w=600&auto=format&fit=crop',
        description: 'Acoustically tuned singing bowl coupled with robust solid mahogany strikers.'
      }
    ],
    processSteps: [
      { name: 'WELLNESS CAPSULES', image: 'https://images.unsplash.com/photo-1584017911766-d451b3d0e843?q=80&w=300&auto=format&fit=crop' },
      { name: 'CALMING ELIXIR', image: 'https://images.unsplash.com/photo-1518241353330-0f7941c2d9b5?q=80&w=300&auto=format&fit=crop' },
      { name: 'MINDFULNESS SET', image: 'https://images.unsplash.com/photo-1602143407151-7111542de6e8?q=80&w=300&auto=format&fit=crop' }
    ]
  }
};
